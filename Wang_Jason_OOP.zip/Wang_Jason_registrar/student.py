#Jason Wang
#BUS216
#OOP

from person import Person
from section import Section


class Student(Person):
    """
    Class is Students - with attribute of name, ID and empty schedule

    Methods: Add, Drop, Print Schedule
        Add: if is an instance of class (i.e. is a person/student) and if the section is not within the instance.schedule, then it adds

        Drop: Same as above, but only drops if the section is within the instance.schedule

        Print: Prints instance.schedule aka the self.schedule = [*****]

    """


    def __init__(self, name, u_id):
        super().__init__(name, u_id)
        self.schedule = []

    def add(self, section):
        # checks for duplicate enrollment
        if section in self.schedule:
            print(f"Student {self.name} is already in section {section.section_id}.")
            return False

        # checks for time block conflicts
        for s in self.schedule:
            if s.time_block == section.time_block:
                print(
                    f'Time conflict: Student {self.name} is already in a section at time block {section.time_block}.')
                return False

        self.schedule.append(section)
        return True

    def drop(self, section):
        if section in self.schedule:
            self.schedule.remove(section)
            return True
        print(f'Student {self.name} is not in section {section.section_id}.')
        return False

    def print_schedule(self):
        print(f'{self.name} Schedule:')
        for section in self.schedule:
            print(section)
