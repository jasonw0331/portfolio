#Jason Wang
#BUS216
#OOP

class Person:
    """
        Class Person
        Attribute of this class (properties associated): Name, ID
            self.name = name --> if input is (Jason, 999 )
             ThisInstance.name = Jason, ThisInstance.id = 9999

        __eq__ Equal aka ==:
            if isinstance(other, Person): checks whether the 'other' object is an instance of the Person class. AKA if other is a person
                return self.u_id == other.u_id --> second round check, to check if ID of other' an instance ' and the ID of person is the same.

        __ne__ Not Equal aka !=: Directs to the __eq__ function, and gets opposite outcome with 'not'

        """
    def __init__(self, name, u_id):
        self.name = name
        self.u_id = u_id

    def __eq__(self, other):
        if isinstance(other, Person):
            return self.u_id == other.u_id
        else:
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __str__(self):
        return f'{self.name}: {self.u_id}'
