# Jason Wang
# BUS216
# OOP
# Due Nov 17 11:59PM

from registrar import Registrar

def get_valid_instructor(registrar):
    """
    while true -> execute code repeatedly, prevents loss of data of schedule
        finds instructor with ID
            If is within the registrar 'self.instructors = {}'
                then returns 'registrar.instructors[instructor_id]' --> instructor/instance = registrar.instructors[instructor_id]
    """
    while True:
        instructor_id = input('Enter Instructor ID: ')
        if instructor_id in registrar.instructors:
            return registrar.instructors[instructor_id]
        print(f'Instructor with ID {instructor_id} not found. Please try again.')

def get_valid_student(registrar):
    """
        finds student with ID
            If is within the registrar 'self.students = {}'
                then returns 'registrar.students[students_id]' --> student/instance = registrar.student[student_id]
    """
    while True:
        student_id = input('Enter Student ID: ')
        if student_id in registrar.students:
            return registrar.students[student_id]
        print(f'Student with ID {student_id} not found. Please try again.')

def get_valid_section(registrar):
    """
        finds section ID, needs to be inputted exactly like those listed within section (Math 001-1, etc)
            When found within the list 'self.sections = {}', it will return and = section
    """
    while True:
        section_id = input('Enter Section ID: ')
        if section_id in registrar.sections:
            return registrar.sections[section_id]
        print(f'Section with ID {section_id} not found. Please try again.')

def update_instructors(registrar):
    print('\nUpdate Instructors')
    """
        Input determines which action to do
        when specific instructor ID is executed ex. J-1, it = instructor, then section.
            Then included with specific method within Class of Instructor --> action execution
                ex.  instructor.assign(section) ... .drop(), .print_schedule()
        Option 3: 
            View a individual instance schedule, same as above but no need for section, and straight into .print_schedule()
        Option 4:
            For loop which prints all instructors and their ID, incase user forgets
    """
    while True:
        try:
            print('\nInstructor Options:')
            print('1. Add Section')
            print('2. Drop Section')
            print('3. View Individual Schedule')
            print('4. View All Instructors')
            print('0. Back')
            choice = input('Select an option (0-4): ')

            if choice == '1':
                instructor = get_valid_instructor(registrar)
                section = get_valid_section(registrar)
                instructor.assign(section)

            elif choice == '2':
                instructor = get_valid_instructor(registrar)
                section = get_valid_section(registrar)
                instructor.drop(section)

            elif choice == '3':
                instructor = get_valid_instructor(registrar)
                instructor.print_schedule()

            elif choice == '4':
                print('\nAll Instructors:')
                for instructor_id in registrar.instructors:
                    instructor = registrar.instructors[instructor_id]
                    print(f'Instructor ID: {instructor_id}, Name: {instructor.name}')

            elif choice == '0':
                return

            else:
                print('Invalid option. Please try again.')
        except ValueError:
            print('Invalid option. Please try again.')


def update_students(registrar):
    print('\nUpdate Students')
    """
    Same as above but within Students Class
    """
    while True:
        try:
            print('\nStudent Options:')
            print('1. Add Section')
            print('2. Drop Section')
            print('3. View Individual Schedule')
            print('4. View All Students')
            print('0. Back')
            choice = input('Select an option (0-4): ')

            if choice == '1':
                student = get_valid_student(registrar)
                section = get_valid_section(registrar)
                student.add(section)

            elif choice == '2':
                student = get_valid_student(registrar)
                section = get_valid_section(registrar)
                student.drop(section)

            elif choice == '3':
                student = get_valid_student(registrar)
                student.print_schedule()

            elif choice == '4':
                print('\nAll Students:')
                for student_id in registrar.students:
                    student = registrar.students[student_id]
                    print(f'Student ID: {student_id}, Name: {student.name}')


            elif choice == '0':
                return

            else:
                print('Invalid option. Please try again.')
        except ValueError:
            print('Invalid option. Please try again.')

def view_schedule(registrar):
    print('\nView Schedule')
    """
        Menu view schedule
            Whole view, either students, instructors or both.
                Done with loop of given selection, and its respective .print_schedule()
    """
    while True:
        try:
            print('\n1. View All Instructors Schedules')
            print('2. View All Students Schedules')
            print('3. View Select Individual Schedule')
            print('4. View All Schedules')
            print('0. Back')
            choice = input('Select an option (0-4): ')

            if choice == '1':
                print('\nCurrent Instructor Schedules:')
                for instructor_id in registrar.instructors:
                    instructor = registrar.instructors[instructor_id]
                    instructor.print_schedule()

            elif choice == '2':
                print('\nCurrent Student Schedules:')
                for student_id in registrar.students:
                    student = registrar.students[student_id]
                    student.print_schedule()

            elif choice == '3':
                print('\n1. Instructors')
                print('2. Students')
                print('0. Back')
                choice = input('Select an option (0-2): ')

                if choice == '1':
                    instructor = get_valid_instructor(registrar)
                    instructor.print_schedule()
                elif choice == '2':
                    student = get_valid_student(registrar)
                    student.print_schedule()
                elif choice == '0':
                    return
                else:
                    print('Invalid option. Please try again.')

            elif choice == '4':
                print('\nCurrent Instructor Schedules:')
                for instructor_id in registrar.instructors:
                    instructor = registrar.instructors[instructor_id]
                    instructor.print_schedule()

                print('\nCurrent Student Schedules:')
                for student_id in registrar.students:
                    student = registrar.students[student_id]
                    student.print_schedule()

            elif choice == '0':
                return

            else:
                print('Invalid option. Please try again.')
        except ValueError:
            print('Invalid option. Please try again.')

def main():
    registrar = Registrar()

    # Load data
    registrar.read_students('data/students.csv')
    registrar.read_instructors('data/instructors.csv')
    registrar.read_courses('data/courses.csv')
    registrar.read_sections('data/sections.csv')
    registrar.read_instructor_section('data/instructor_section.csv')    #CSV file with default instructor and their sections. In menu able to adjust (add drop and view)
    registrar.read_student_section('data/student_section.csv')          #CSV file with default students and their sections. In menu able to adjust (add drop and view)

    """
        Main menu, to navigate and update instructors or students, View schedule. Or end system, which resets back to default. Clearing all actions 
    """

    while True:
        print('\nMain Menu:')
        print('1. Update Instructors')
        print('2. Update Students')
        print('3. View Schedule')
        print('0. End Scheduling')
        choice = input('Select an option (0-3): ')

        if choice == '1':
            update_instructors(registrar)
        elif choice == '2':
            update_students(registrar)
        elif choice == '3':
            view_schedule(registrar)
        elif choice == '0':
            break
        else:
            print('Invalid choice. Please try again.')

if __name__ == '__main__':
    main()
