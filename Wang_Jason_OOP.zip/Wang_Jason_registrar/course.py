#Jason Wang
#BUS216
#OOP

class Course:
    """
       Class: Course

       __init__ set for each instance (aka each course needs) is (course_id, name, number_of_credits)
          It is also a given attribute for a class. In this case the attribute of course is its ID, Name and Credit

      __str__ structures object into ID:NAME:CREDIT
       """

    def __init__(self, course_id, name, number_of_credits):
        self.course_id = course_id
        self.name = name
        self.number_of_credits = number_of_credits

    def __str__(self):
        return f'{self.course_id}: {self.name}: {self.number_of_credits}'


if __name__ == '__main__':
    c1 = Course('DYN401', 'Digital Signal Processing (DSP)', 4)
    c2 = Course('DYN402', 'DSP Laboratory', 2)
    c3 = Course('DYN403', 'Sprectral Analysis', 4)

    print(c1)
    print(c2)
    print(c3)
