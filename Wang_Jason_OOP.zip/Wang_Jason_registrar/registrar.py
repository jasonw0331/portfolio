#Jason Wang
#BUS216
#OOP

import csv

from student import Student
from instructor import Instructor
from course import Course
from section import Section


class Registrar:
    """
            Class is Registrar
            Attribute of this class (properties associated): Students, Instructors, Courses, Sections
                Which are all dictionaries
            Methods (actions an object can perform):
                    Each method prints formated output of the length of the dictionary ( # of x )

                read_students: Taps into students CSV, loops over each row and creates each student instance
                                    Name is 0th index and id is 1th
                               Creates student, which is = to name(0th), id (1th)
                               stores into dictionary - self.students[u_id] - and ID is the key

                read_instructors: Same as above
                read_courses: Same as above
                read_sections: Same as above, with added timeblock
            """

    def __init__(self):
        self.students = {}
        self.instructors = {}
        self.courses = {}
        self.sections = {}

    def read_students(self, file):
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                name = row[0]
                u_id = row[1]
                student = Student(name, u_id)
                self.students[u_id] = student
            print(f'Number of students: {len(self.students)}')

    def read_instructors(self, file):
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                name = row[0]
                u_id = row[1]
                instructor = Instructor(name, u_id)
                self.instructors[u_id] = instructor
            print(f'Number of intructors: {len(self.instructors)}')

    def read_courses(self, file):
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                c_id = row[0]
                name = row[1]
                number_of_credits = int(row[2])
                course = Course(c_id, name, number_of_credits)
                self.courses[c_id] = course
            print(f'Number of Courses: {len(self.courses)}')

    def read_sections(self, file):
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                s_id = row[0]
                c_id = row[1]
                time_block = row[2]
                section = Section(s_id, c_id, time_block)
                self.sections[s_id] = section
            print(f'Number of Sections: {len(self.sections)}')

    def read_instructor_section(self, file):
        """
        reads instructor_section.csv and if row has both a instructor and a section, it gets added/assigned into 'self.instructors = {}'

        """
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                instructor_id = row[0]
                section_id = row[1]
                instructor = self.instructors.get(instructor_id)
                section = self.sections.get(section_id)
                if instructor and section:
                    instructor.assign(section)
                else:
                    print(f'Invalid instructor or section: {instructor_id}, {section_id}')

    def read_student_section(self, file):
        """
            same as above but for students

        """
        with open(file, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                student_id = row[0]
                section_id = row[1]
                student = self.students.get(student_id)
                section = self.sections.get(section_id)
                if student and section:
                    student.add(section)
                else:
                    print(f'Invalid student or section: {student_id}, {section_id}')




