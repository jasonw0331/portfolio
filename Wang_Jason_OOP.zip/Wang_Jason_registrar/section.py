#Jason Wang
#BUS216
#OOP


class Section:
    """
        Class is section
        Attribute of this class (properties associated): section_id, course_id, time_block
    """
    def __init__(self, section_id, course_id, time_block):
        self.section_id = section_id
        self.course_id = course_id
        self.time_block = time_block

    def __str__(self):
        return f'{self.section_id}: {self.course_id}: {self.time_block}'
