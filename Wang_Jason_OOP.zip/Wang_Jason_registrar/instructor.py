#Jason Wang
#BUS216
#OOP

from person import Person
from section import Section

class Instructor(Person):
    """
        Class is instructor - with attribute of name, ID and empty schedule

        Methods: Add, Drop, Print Schedule
            Add: if is an instance of class (i.e. is a person/instructor) and if the section is not within the instance.schedule, then it adds

            Drop: Same as above, but only drops if the section is within the instance.schedule

            Print: Prints instance.schedule aka the self.schedule = [*****]

        """

    def __init__(self, name, u_id):
        super().__init__(name, u_id)
        self.schedule = []

    def assign(self, section):
        # checks for duplicate
        if section in self.schedule:
            print(
                f'Instructor {self.name} is already assigned to section {section.section_id}.')
            return False

        # checks for conflicts
        for s in self.schedule:
            if s.time_block == section.time_block:
                print(
                    f'Time conflict: {self.name} is already in {section.time_block}.')
                return False

        self.schedule.append(section)
        return True

    def drop(self, section):
        if section in self.schedule:
            self.schedule.remove(section)
            return True
        print(f' {self.name} does not have {section.section_id}.')
        return False

    def print_schedule(self):
        print(f'{self.name} Schedule:')
        for section in self.schedule:
            print(section)
